<h2>Nombre: <?php echo e($name); ?></h2>
<h2>Email: <?php echo e($email); ?></h2>
<h2>Celular: <?php echo e($celular); ?></h2>
<h2>Mensaje: <?php echo e($msg); ?></h2>
<?php /**PATH C:\Users\Cristina\Desktop\Prac\practica\resources\views/email.blade.php ENDPATH**/ ?>