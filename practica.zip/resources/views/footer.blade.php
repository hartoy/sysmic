<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

    <link rel="stylesheet" href="css/footer.css">
  </head>
  <body>

  </body>
</html>
<footer >
  <div class="sysmic">
    <img src="img/sysimicletrasblanco.jpg" alt=""class="d-block mx-auto w-25 logo-navbar">
    <h5> SYSMIC ®</h5>
    <h4><a href="contacto"> CONTACT US</a></h4>
  </div>
</footer>
